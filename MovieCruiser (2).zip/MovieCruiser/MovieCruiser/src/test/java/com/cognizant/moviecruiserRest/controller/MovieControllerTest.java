package com.cognizant.moviecruiserRest.controller;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class MovieControllerTest {

	@BeforeEach
	void setUp() throws Exception {
	}

	@Test
	void testGetMovie() {
		fail("Not yet implemented");
	}

}
