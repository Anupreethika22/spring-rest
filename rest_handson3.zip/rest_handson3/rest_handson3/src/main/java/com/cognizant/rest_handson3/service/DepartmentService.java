package com.cognizant.rest_handson3.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.rest_handson3.dao.DepartmentDao;
import com.cognizant.rest_handson3.model.Department;

@Service
public class DepartmentService {

	@Autowired
	DepartmentDao depDao;
	
	public ArrayList<Department> getAllDepartments(){
		return depDao.getAllDepartments();
	}
}
