package com.cognizant.rest_handson3.service;

import java.util.ArrayList;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.rest_handson3.dao.EmployeeDao;
import com.cognizant.rest_handson3.model.Employee;

@Service
public class EmployeeService {

	@Autowired
	EmployeeDao employeeDao;
	
	
	public ArrayList<Employee> getAllEmployees(){
		return employeeDao.getAllEmployees();
	}
	
	public void updateEmployee(Employee emp) throws EmployeeNotFoundException{
		employeeDao.updateEmployee(emp);
	}
	
	public void deleteEmployee(int id) throws EmployeeNotFoundException{
		employeeDao.deleteEmployee(id);
	}
}
